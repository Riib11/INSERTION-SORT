import display as d

# functions for running hte scenes involved in the animations

def intro():
    d.intro()

def lose():
    d.lose()

def end():
    d.breakdown()
    d.end_dialogues()
    d.rotate()