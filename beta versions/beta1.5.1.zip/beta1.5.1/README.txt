frequent abbreviations in my code:

t: target
suc: success
