# a print with a debug tag
def dprint(s):
    print("[debug]",s)