import display as d

def intro():
    d.intro()

def lose():
    d.lose()

def end():
    d.breakdown()
    d.end_dialogues()
    d.rotate()