def dprint(s):
    print("[debug]",s)